export interface Person{
	personName:string,
	personAge:number
}