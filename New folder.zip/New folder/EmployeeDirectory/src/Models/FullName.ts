export class FormatName{
   
    private _fullName:string;
    constructor(firstname:string,lastname:string){
       this._fullName = `${firstname} ${lastname}`;
    }
    get fullName():string{
        return this._fullName;
    }
}