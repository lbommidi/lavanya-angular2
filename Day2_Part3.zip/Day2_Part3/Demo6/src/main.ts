import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule }      from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();

@Component({
   selector: 'my-app';
   template:`
	<h1> Welcome to two way binding</h1>
	Enter a data:<input type="text" [(ngModel)]="t1">
	<hr/>
	<h1> The value in the text box is {{t1}}</h1>
	<hr/>
	Choose your nation:
	<select [(ngModel)]="country">
	<option value="">--Select--</option>
	 <option value="India">India</option>
	 <option value="China">China</option>
	 <option value="Australia">Oz</option>
	 <option value="America">USA</option>
	</select>
	<hr/>
	<h1> You are from {{country}}</h1>
   `
})

export class AppComponent {
 t1:string="Welcome";
 country:string="";
}

@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);
