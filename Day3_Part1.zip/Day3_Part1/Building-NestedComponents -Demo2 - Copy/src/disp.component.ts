import {Component,Input} from '@angular/core';

@Component({
  selector: 'child-selector',
  template: `<h2>From display component</h2>
		<div *ngIf="type=='emp'">
		<h1> Employee Data</h1>
		  <div *ngFor="let e of data">
		    <span>
		       Eid : {{e.id}}  Name : {{e.name}}
			</span>
		  </div>
			<hr/>		  
		</div>
		<div *ngIf="type=='stud'">
		<h1> Student Data</h1>
		  <div *ngFor="let e of data">
		    <span>
		       Name : {{e.name}}  Grade : {{e.grade}}
			</span>
		  </div>	
		  <hr/>	
		</div>
		<div *ngIf="type=='account'">
		<h1> Account Data</h1>
		  <div *ngFor="let e of data">
		    <span>
		       Account Id : {{e.id}}  Balance : {{e.balance}}
			</span>
		  </div>	
		  <hr/>	
		</div>

  `
  
})
export class DispComponent {  
  @Input() data:any;
  @Input() type:string;
}

