export interface Student{
	name:string,
	grade:string
}