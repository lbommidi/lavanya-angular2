import {Component,Input,Output,EventEmitter} from '@angular/core';
import {ChildComponent } from './inner.component';

@Component({
  selector: 'my-app',
  template: `<div>  
				<h1>I'm a container component</h1>
				<child-selector 
					(nameFetch)='f1($event)' 
					(workFetch)='f2($event)'>
				</child-selector>
				<h2> Name : {{name}}</h2>
			    <h2> Desig : {{desig}}</h2>
				</div>`,
  directives: [ChildComponent]
})
export class ParentComponent { 
   name:string="No Name"; 
    desig:string="No Job"; 
  f1(message:string):void {
	this.name=message;
  }
  f2(message:string):void {
	this.desig=message;
  }
}