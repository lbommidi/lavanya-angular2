import { Component,NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { enableProdMode } from '@angular/core';
enableProdMode();

@Component({
  selector: 'my-app',
  template: `<div>
	<div *ngIf="no==10">Number is 10</div>
	<br/>
	<h1> Student detials </h1>
	<div *ngFor="let s1 of students">
	
	   <h3> Name : {{s1.name}} Score : {{s1.total}}</h3>
	   <h3 *ngIf="s1.name=='Allen'">You are the topper</h3>
	   <h3 *ngIf="s1.total>70">
	   Result is Pass</h3>
	   <h3 *ngIf="s1.total<70">Result is Fail</h3>
	   <hr/>
	</div>
  <div>`
})

export class StructuralComponent {
	no:number=10;
	students:any[]=[
	{id:101,name:"Allen",total:89},
	{id:102,name:"Mark",total:42},
	{id:103,name:"Steve",total:27},
	{id:104,name:"Smith",total:93},
	]
}

@NgModule({
  imports:[ BrowserModule ],
  declarations:[ StructuralComponent ],
  bootstrap:[ StructuralComponent ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);


  