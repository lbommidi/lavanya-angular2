//app.component.ts - this is where we define our root component
import { Component } from '@angular/core'
import { IEmployee } from './employee.component'
@Component({
selector: 'my-app',
templateUrl: 'src/emp.html'
})
export class AppComponent implements IEmployee { 

	employee:IEmployee={};
	show:boolean=false;
	empId:number=0;
private emps:IEmployee[];
	emps=[  
	 { "id": 101, "name": "Ram","salary":20000 },    
	 { "id": 104, "name": "Ravan","salary":25000 },    
	 { "id": 109, "name": "Lakshman","salary":30000 },   
	 { "id": 121, "name": "Krish","salary":47855 },    
	 { "id": 141, "name": "Lava","salary":42589 },    
	 { "id": 155, "name": "Kucha","salary":54236},  
	 { "id": 167, "name": "Shiv","salary":65220 }			 
  ];
	details(){
		this.show=false;
		for(let i=0;i<(this.emps).length;i++)
		{
			if((this.emps[i]).id==this.empId)
			{
				this.show=true;
				this.employee=this.emps[i];
			}
			else
			{
				continue;
			}
		}	
	}
			

}


