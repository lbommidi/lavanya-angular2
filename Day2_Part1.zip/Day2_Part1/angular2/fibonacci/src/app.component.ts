//app.component.ts - this is where we define our root component
import { Component } from '@angular/core'
@Component({
selector: 'my-app',
template: `
			<button type='button' (click)='check()' >Next Number</button>
			<h1 *ngIf="show">{{res}}</h1>`
})
export class AppComponent { 

		values:number;
		show:boolean=false;
		result:number;
		count:number=0;
		first:number=0;
		second:number=1;
		res:string="";
		check(){
		this.show=true;
				if(this.count==0){
					this.result=0;
					this.res+=this.result;
					this.count++;
				}
				else if(this.count==1){
					this.result=this.second;
					this.res+=","+this.result;
					this.count++;
				}
				else{
					
					this.result=this.first+this.second;
					this.res+=","+this.result;
					this.first=this.second;
					this.second=this.result;
					this.count++;
				}
		}

}


