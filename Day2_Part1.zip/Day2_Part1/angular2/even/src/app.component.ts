//app.component.ts - this is where we define our root component
import { Component } from '@angular/core'
@Component({
selector: 'my-app',
template: `<input type="text"  (keyup)='onKey($event)'/>
			<button type='button' (click)='check()' >Submit</button>
			<h1 *ngIf="show">{{result}}</h1>`
})
export class AppComponent { 

		values:number;
		show:boolean=false;
		result:string;
		onKey(event:number){
		this.show=false;
			this.values=event.target.value;
			
			
		}
		check(){
		this.show=true;
				if(this.values%2==0)
			{
				this.result="even";
			}
			else
			{
				this.result="odd";
			}
		}

}


