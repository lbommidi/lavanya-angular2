//app.component.ts - this is where we define our root component
import { Component } from '@angular/core'
@Component({
selector: 'my-app',
template: `<select name="drop" (change)="check($event)" >Select
<option value="coconut" > Coconut </option>
<option value="fan" > Fan </option>
<option value="panda" > Panda </option>
<option value="ice" > Ice Cream </option>	</select>	
<img [src]="photo" />	`
})
export class AppComponent { 

		pho:string;
		photo:string="";
		show:boolean=false;
		
		check(event:string){
			this.pho=event.target.value;
			this.photo="./images/"+this.pho+".jpg";
			
				
		}

}


