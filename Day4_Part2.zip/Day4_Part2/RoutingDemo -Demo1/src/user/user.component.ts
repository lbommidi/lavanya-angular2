import { Component,Injectable,Inject } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';

@Component({
  template: `<div>
	<h1>Get Details from Home page</h1>
	<h1> The id passed is {{id}}</h1>
	<input type="text" (keyup)='onKey($event)'/>
	<hr/>
	<input type="submit" (click)='showValue()' value="Submit"/>
	<h1 *ngIf="show" [innerText]='values'></h1>
	<hr/>
	<h1>A new Component invoked</h1>
  <div>`
})
export class UserComponent {
	values:string="";
	show:boolean=false;
	id:number;
	 constructor(@Inject(ActivatedRoute) private route:ActivatedRoute){
          this.id = parseInt(this.route.snapshot.params['userId']);
    }
	onKey(event:any) {
	    this.show=false;
		this.values = event.target.value;
	};
	showValue() {
	    this.show=true;
	};
}
