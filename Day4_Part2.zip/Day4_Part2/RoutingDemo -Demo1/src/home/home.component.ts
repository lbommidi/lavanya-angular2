import { Component } from '@angular/core';

@Component({
  template: `<div>
	<h2> Welcome to Home Page</h2>
  <div>`
})
export class HomeComponent {
	values:string="";
	show:boolean=false;
	onKey(event:any) {
	    this.show=false;
		this.values = event.target.value;
	};
	showValue() {
	    this.show=true;
	};
}

