import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Routes, RouterModule }   from '@angular/router';
import { HomeComponent } from './home/home.component';
import { DisplayComponent } from './display/display.component';
import { DisplayService } from './display/display.service';
import { ViewEmployeeComponent } from './viewemp/emp.component';
import { EmployeeService } from './viewemp/employee.service';
import { EmpComponent } from './addemp/Employee.component';
import { SuccessComponent } from './success/success.component';
import { SearchComponent } from './search/search.component';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';


enableProdMode();

@Component({
  selector: 'my-app',
   templateUrl:'src/main.html'
})
export class AppComponent { 
}

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home',  component: HomeComponent },
  { path: 'addEmp',  component: EmpComponent },
   { path: 'viewEmp', component: ViewEmployeeComponent },
    { path: 'success', component: SuccessComponent },
	{ path: 'about/:id', component: DisplayComponent }
	{ path: 'search', component: SearchComponent }
];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true }),FormsModule,HttpModule],
    declarations:[ AppComponent, HomeComponent, ViewEmployeeComponent,EmpComponent,DisplayComponent,SuccessComponent,SearchComponent],
	providers:[EmployeeService,DisplayService],
    bootstrap:[ AppComponent ]
})
export class AppModule {
}
platformBrowserDynamic().bootstrapModule(AppModule);